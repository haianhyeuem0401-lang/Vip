const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.json({
    status: "ok",
    service: "Patch Resource Server",
    version: "1.0.0"
  });
});

app.get("/health", (req, res) => {
  res.json({ ok: true });
});

app.get("/patch", (req, res) => {
  res.json({
    enabled: true,
    version: "1.0.0",
    resource_url: "/patch/resource.dat"
  });
});

app.get("/patch/resource.dat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "patch", "resource.dat"));
});

app.use((req, res) => {
  res.status(404).json({
    error: "not_found",
    path: req.path
  });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server listening on port ${PORT}`);
});
