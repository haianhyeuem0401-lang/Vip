# Patch Resource Server

Server mẫu để deploy lên Render cho ứng dụng của bạn.

## Deploy trên Render

1. Tạo một GitHub repository và upload toàn bộ thư mục này.
2. Vào Render -> New -> Web Service.
3. Chọn repository.
4. Runtime: Node.
5. Build Command:
   npm install
6. Start Command:
   npm start
7. Deploy.

## Endpoint

GET /
- Kiểm tra server.

GET /health
- Health check.

GET /patch
- Trả thông tin resource.

GET /patch/resource.dat
- Trả file resource.dat.

## Thay resource

Thay file:
public/patch/resource.dat

bằng resource hợp lệ của chính ứng dụng của bạn.

Lưu ý:
- Không đặt API key hoặc mật khẩu quản trị trong mã nguồn.
- Nếu resource cần bảo vệ, hãy thêm xác thực phía server.
